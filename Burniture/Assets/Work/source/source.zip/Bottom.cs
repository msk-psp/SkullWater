﻿using UnityEngine;
using System.Collections;

public class Bottom : MonoBehaviour {

	public void copy()
    {
        GameObject Sphere1 = GameObject.FindGameObjectWithTag("Sphere1");
        GameObject Sphere2 = GameObject.FindGameObjectWithTag("Sphere2");
        GameObject Sphere3 = GameObject.FindGameObjectWithTag("Sphere3");
        GameObject Sphere4 = GameObject.FindGameObjectWithTag("Sphere4");
        GameObject Sphere5 = GameObject.FindGameObjectWithTag("Sphere5");
        GameObject Sphere6 = GameObject.FindGameObjectWithTag("Sphere6");
        GameObject Sphere7 = GameObject.FindGameObjectWithTag("Sphere7");
        GameObject Sphere8 = GameObject.FindGameObjectWithTag("Sphere8");
        GameObject line1 = GameObject.FindGameObjectWithTag("Line 12");
        GameObject line2 = GameObject.FindGameObjectWithTag("Line 34");
        GameObject line3 = GameObject.FindGameObjectWithTag("Line 14");
        GameObject line4 = GameObject.FindGameObjectWithTag("Line 23");
        GameObject line5 = GameObject.FindGameObjectWithTag("Line 45");
        GameObject line6 = GameObject.FindGameObjectWithTag("Line 36");
        GameObject line7 = GameObject.FindGameObjectWithTag("Line 27");
        GameObject line8 = GameObject.FindGameObjectWithTag("Line 18");
        GameObject line9 = GameObject.FindGameObjectWithTag("Line 78");
        GameObject line10 = GameObject.FindGameObjectWithTag("Line 67");
        GameObject line11 = GameObject.FindGameObjectWithTag("Line 56");
        GameObject line12 = GameObject.FindGameObjectWithTag("Line 58");

        GameObject obj;

        obj=Instantiate(Sphere1);
        obj.transform.position = Sphere1.transform.position;
        obj=Instantiate(Sphere2);
        obj.transform.position = Sphere2.transform.position;
        obj =Instantiate(Sphere3);
        obj.transform.position = Sphere3.transform.position;
        obj =Instantiate(Sphere4);
        obj.transform.position = Sphere4.transform.position;
        obj =Instantiate(Sphere5);
        obj.transform.position = Sphere5.transform.position;
        obj = Instantiate(Sphere6);
        obj.transform.position = Sphere6.transform.position;
        obj =Instantiate(Sphere7);
        obj.transform.position = Sphere7.transform.position;
        obj =Instantiate(Sphere8);
        obj.transform.position = Sphere8.transform.position;
        obj =Instantiate(line1);
        obj.transform.position = line1.transform.position;
        obj =Instantiate(line2);
        obj.transform.position = line2.transform.position;
        obj =Instantiate(line3);
        obj.transform.position = line3.transform.position;
        obj =Instantiate(line4);
        obj.transform.position = line4.transform.position;
        obj =Instantiate(line5);
        obj.transform.position = line5.transform.position;
        obj =Instantiate(line6);
        obj.transform.position = line6.transform.position;
        obj =Instantiate(line7);
        obj.transform.position = line7.transform.position;
        obj =Instantiate(line8);
        obj.transform.position = line8.transform.position;
        obj =Instantiate(line9);
        obj.transform.position = line9.transform.position;
        obj =Instantiate(line10);
        obj.transform.position = line10.transform.position;
        obj =Instantiate(line11);
        obj.transform.position = line11.transform.position;
        obj =Instantiate(line12);
        obj.transform.position = line12.transform.position;

        //IN.transform.position = bundle.transform.position;
    }
}
